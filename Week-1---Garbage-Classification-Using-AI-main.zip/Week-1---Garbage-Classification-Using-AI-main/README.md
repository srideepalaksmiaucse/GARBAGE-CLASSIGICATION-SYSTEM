# Week-1---Garbage-Classification-Using-AI
AI-powered waste classification system using deep learning (CNN) to automatically categorize garbage into different types — promoting smart, sustainable waste management.
